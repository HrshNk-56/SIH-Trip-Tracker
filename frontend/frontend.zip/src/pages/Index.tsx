import DashboardHeader from "@/components/DashboardHeader";
import TripOverview from "@/components/TripOverview";
import BudgetTracker from "@/components/BudgetTracker";
import WeatherWidget from "@/components/WeatherWidget";
import QuickActions from "@/components/QuickActions";

const Index = () => {
  return (
    <div className="min-h-screen bg-background py-4 px-4">
      <div className="mobile-container">
        {/* Dashboard Header */}
        <DashboardHeader />
        
        {/* Main Dashboard Content */}
        <div className="p-6 space-y-6">
          {/* Trip Overview */}
          <TripOverview />
          
          {/* Budget & Weather */}
          <BudgetTracker />
          <WeatherWidget />
          
          {/* Quick Actions */}
          <QuickActions />
        </div>
      </div>
    </div>
  );
};

export default Index;
